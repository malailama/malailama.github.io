// Content script for JoyScroller Chrome Extension

let timerElement = null;

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getPageInfo") {
    sendResponse({
      title: document.title,
      url: window.location.href,
      domain: window.location.hostname,
      description: getPageDescription(),
      favicon: getFavicon()
    });
  } else if (request.action === "showTimer") {
    showTimer();
  } else if (request.action === "hideTimer") {
    hideTimer();
  }
});

// Check if timer should be shown when page loads - only for tabs opened from JoyScroller
chrome.storage.local.get(['timerActive', 'timerTabId'], (result) => {
  // Get current tab ID
  chrome.runtime.sendMessage({ action: 'getCurrentTabId' }, (response) => {
    if (result.timerActive && response.tabId && result.timerTabId === response.tabId) {
      showTimer();
    }
  });
});

// Show reading timer on page
function showTimer() {
  if (timerElement) return; // Already showing
  
  timerElement = document.createElement('div');
  timerElement.id = 'joyscroller-timer';
  timerElement.innerHTML = `
    <div style="
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.3);
      z-index: 10000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      width: 280px;
    ">
      <div style="display: flex; align-items: center; justify-content: between; margin-bottom: 12px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <div style="width: 8px; height: 8px; background: #3b82f6; border-radius: 50%;"></div>
          <span style="font-size: 14px; font-weight: 500; color: #1e293b;">Mindful Session</span>
        </div>
        <button id="joyscroller-close-timer" style="
          background: none;
          border: none;
          font-size: 18px;
          cursor: pointer;
          color: #64748b;
          padding: 0;
          margin-left: auto;
        ">&times;</button>
      </div>
      
      <div style="text-align: center; margin-bottom: 16px;">
        <div id="joyscroller-timer-display" style="font-size: 32px; font-weight: 600; color: #1e293b; margin-bottom: 8px;">25:00</div>
        <div style="background: #f1f5f9; height: 4px; border-radius: 2px; overflow: hidden;">
          <div id="joyscroller-timer-progress" style="background: #3b82f6; height: 100%; width: 100%; border-radius: 2px; transition: width 1s ease;"></div>
        </div>
      </div>
      
      <div style="display: flex; gap: 8px; justify-content: center;">
        <button id="joyscroller-start-timer" style="
          background: #3b82f6;
          color: white;
          border: none;
          padding: 8px 16px;
          border-radius: 6px;
          font-size: 14px;
          cursor: pointer;
          flex: 1;
        ">Start</button>
        <button id="joyscroller-pause-timer" style="
          background: #64748b;
          color: white;
          border: none;
          padding: 8px 16px;
          border-radius: 6px;
          font-size: 14px;
          cursor: pointer;
          flex: 1;
        ">Pause</button>
        <button id="joyscroller-reset-timer" style="
          background: #f1f5f9;
          color: #64748b;
          border: 1px solid #e2e8f0;
          padding: 8px 16px;
          border-radius: 6px;
          font-size: 14px;
          cursor: pointer;
          flex: 1;
        ">Reset</button>
      </div>
      
      <div style="text-align: center; margin-top: 12px; font-size: 12px; color: #64748b;">
        Stay focused and browse mindfully
      </div>
    </div>
  `;
  
  document.body.appendChild(timerElement);
  
  // Add event listeners
  let timeLeft = 25 * 60; // 25 minutes in seconds
  let isActive = false;
  let isPaused = false;
  let interval = null;
  
  const timerDisplay = document.getElementById('joyscroller-timer-display');
  const timerProgress = document.getElementById('joyscroller-timer-progress');
  const startBtn = document.getElementById('joyscroller-start-timer');
  const pauseBtn = document.getElementById('joyscroller-pause-timer');
  const resetBtn = document.getElementById('joyscroller-reset-timer');
  const closeBtn = document.getElementById('joyscroller-close-timer');
  
  function updateDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    const progress = ((25 * 60 - timeLeft) / (25 * 60)) * 100;
    timerProgress.style.width = `${progress}%`;
  }
  
  function startTimer() {
    if (!isActive && !isPaused) {
      timeLeft = 25 * 60;
    }
    isActive = true;
    isPaused = false;
    startBtn.textContent = 'Running...';
    startBtn.disabled = true;
    
    interval = setInterval(() => {
      timeLeft--;
      updateDisplay();
      
      if (timeLeft <= 0) {
        clearInterval(interval);
        isActive = false;
        startBtn.textContent = 'Start';
        startBtn.disabled = false;
        
        // Show completion notification
        if (Notification.permission === 'granted') {
          new Notification('Mindful Session Complete!', {
            body: 'Great job! You\'ve completed a 25-minute focused session.',
            icon: '/icons/icon48.png'
          });
        }
      }
    }, 1000);
  }
  
  function pauseTimer() {
    if (isActive) {
      clearInterval(interval);
      isActive = false;
      isPaused = true;
      startBtn.textContent = 'Resume';
      startBtn.disabled = false;
    }
  }
  
  function resetTimer() {
    clearInterval(interval);
    isActive = false;
    isPaused = false;
    timeLeft = 25 * 60;
    updateDisplay();
    startBtn.textContent = 'Start';
    startBtn.disabled = false;
  }
  
  startBtn.addEventListener('click', startTimer);
  pauseBtn.addEventListener('click', pauseTimer);
  resetBtn.addEventListener('click', resetTimer);
  closeBtn.addEventListener('click', hideTimer);
  
  updateDisplay();
}

function hideTimer() {
  if (timerElement) {
    timerElement.remove();
    timerElement = null;
    // Clear both timer state and tab ID when hiding
    chrome.storage.local.set({ timerActive: false, timerTabId: null });
  }
}

// Helper function to get page description
function getPageDescription() {
  // Try multiple meta tag variations for description
  const metaSelectors = [
    'meta[name="description"]',
    'meta[property="og:description"]',
    'meta[name="twitter:description"]',
    'meta[property="twitter:description"]',
    'meta[name="description" i]', // case insensitive
    'meta[property="description"]',
    'meta[name="summary"]',
    'meta[property="og:summary"]',
    'meta[name="abstract"]',
    'meta[name="news_keywords"]',
    'meta[property="article:description"]',
    'meta[name="sailthru.description"]',
    'meta[name="parsely-description"]'
  ];
  
  // Try each meta selector
  for (const selector of metaSelectors) {
    const meta = document.querySelector(selector);
    if (meta && meta.content && meta.content.trim().length > 10) {
      return meta.content.trim();
    }
  }
  
  // Try structured data (JSON-LD)
  const jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
  for (const script of jsonLdScripts) {
    try {
      const data = JSON.parse(script.textContent);
      if (data.description) {
        return data.description;
      }
    } catch (e) {
      // Continue to next script
    }
  }
  
  // Try article content selectors
  const contentSelectors = [
    'article p:first-of-type',
    '.article-content p:first-of-type',
    '.post-content p:first-of-type',
    '.entry-content p:first-of-type',
    '.content p:first-of-type',
    'main p:first-of-type',
    '[role="main"] p:first-of-type'
  ];
  
  for (const selector of contentSelectors) {
    const element = document.querySelector(selector);
    if (element && element.textContent && element.textContent.trim().length > 30) {
      const text = element.textContent.trim();
      return text.length > 200 ? text.slice(0, 200) + '...' : text;
    }
  }
  
  // Fallback to any paragraph with substantial content
  const paragraphs = document.querySelectorAll('p');
  for (const p of paragraphs) {
    const text = p.textContent?.trim();
    if (text && text.length > 50 && !text.includes('cookie') && !text.includes('JavaScript')) {
      return text.length > 200 ? text.slice(0, 200) + '...' : text;
    }
  }
  
  // Last resort: try headings
  const headings = document.querySelectorAll('h1, h2, h3');
  for (const heading of headings) {
    const text = heading.textContent?.trim();
    if (text && text.length > 20) {
      return text.length > 150 ? text.slice(0, 150) + '...' : text;
    }
  }
  
  return 'No description available';
}

// Helper function to get favicon
function getFavicon() {
  // Try to find favicon link
  const faviconLink = document.querySelector('link[rel="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"]');
  if (faviconLink && faviconLink.href) {
    return faviconLink.href;
  }
  
  // Fallback to default favicon path
  return `${window.location.protocol}//${window.location.hostname}/favicon.ico`;
}