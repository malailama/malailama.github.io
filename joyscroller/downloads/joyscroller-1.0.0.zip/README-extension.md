# JoyScroller Chrome Extension

Transform doomscrolling into joyscrolling with this minimal, whitespace-rich bookmark manager that replaces your Chrome new tab page.

## 🚀 Installation

### Option 1: Developer Mode (Recommended for Testing)

1. **Build the Extension**
   ```bash
   npm run build
   ```

2. **Load Extension in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right corner)
   - Click "Load unpacked" 
   - Select the `dist` folder from your project

3. **Test the Extension**
   - Open a new tab - you should see JoyScroller instead of the default new tab page
   - Right-click any link on the web to add it to JoyScroller

### Option 2: Build for Chrome Web Store (Production)

1. **Create Production Build**
   ```bash
   npm run build
   ```

2. **Package Extension**
   - Zip the `dist` folder contents
   - Upload to Chrome Web Store Developer Dashboard

## 🎯 Features

### ✨ Core Features
- **New Tab Override**: Replaces Chrome's default new tab with your bookmark feed
- **Daily Highlight**: Featured bookmark with shuffle option for serendipitous discovery
- **Smart Organization**: Automatic categorization (Development, Design, Wellness, etc.)
- **Progress Tracking**: Mark bookmarks as read with visual feedback
- **Right-Click Integration**: Add any webpage to JoyScroller via context menu

### 🎨 Design Features
- **Minimal Interface**: Clean, whitespace-rich design for focused reading
- **Smooth Interactions**: Subtle animations and hover effects
- **Category Colors**: Visual organization with color-coded categories
- **Responsive Design**: Works beautifully on all screen sizes

### 🔧 Chrome Integration
- **Bookmark Sync**: Syncs with Chrome's native bookmark system
- **Context Menus**: Right-click any link to add to JoyScroller
- **Background Processing**: Automatic categorization and metadata extraction
- **Storage Management**: Efficient local storage for fast loading

## 📁 Extension Structure

```
public/
├── manifest.json          # Extension configuration
├── background.js          # Service worker for bookmark management
├── content.js            # Content script for page interaction
├── popup.html            # Extension popup interface
├── popup.js              # Popup functionality
└── icons/                # Extension icons (16, 32, 48, 128px)

dist/                     # Built extension files
├── index.html            # New tab page
├── assets/               # CSS, JS, and other assets
└── ...                   # React app build output
```

## 🛠️ Development

### Local Development
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Extension Development
1. Make changes to the React app or extension files
2. Run `npm run build`
3. Reload the extension in Chrome (`chrome://extensions/`)
4. Open new tab to test changes

## 📋 Permissions Explained

- **bookmarks**: Access and manage Chrome bookmarks
- **storage**: Store bookmark metadata and user preferences
- **activeTab**: Get information about the current tab when adding bookmarks
- **contextMenus**: Add "Add to JoyScroller" to right-click menus

## 🎨 Customization

### Adding New Categories
Edit `src/services/chromeExtensionService.ts`:

```typescript
private categorizeBookmark(title: string, url: string): string {
  // Add your custom categorization logic here
  if (lowerTitle.includes('your-keyword')) {
    return 'Your Category';
  }
  // ... existing categories
}
```

### Modifying Daily Highlight Logic
The daily highlight can be customized in the Chrome extension service to change how bookmarks are selected for featuring.

## 🚀 Publishing to Chrome Web Store

1. **Prepare Extension**
   - Run `npm run build`
   - Test thoroughly in developer mode
   - Create high-quality screenshots

2. **Upload to Chrome Web Store**
   - Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/developer/dashboard)
   - Create new item
   - Upload zipped `dist` folder
   - Fill out store listing details

3. **Store Listing Requirements**
   - Clear description of functionality
   - Screenshots showing the extension in action
   - Privacy policy (if collecting any data)
   - Detailed explanation of permissions used

## 🔧 Troubleshooting

### Extension Not Loading
- Ensure `manifest.json` is valid JSON
- Check that all referenced files exist in the build output
- Review Chrome's extension error logs

### Bookmarks Not Syncing
- Verify bookmark permissions are granted
- Check browser console for errors
- Ensure Chrome sync is enabled

### New Tab Not Replacing
- Confirm `chrome_url_overrides.newtab` points to correct HTML file
- Check for conflicts with other new tab extensions
- Reload extension after making changes

## 📄 License

This project is open source. Feel free to modify and distribute according to your needs.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test the extension thoroughly
5. Submit a pull request

---

**Transform your browsing habits today!** 🌟
