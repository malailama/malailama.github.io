// Popup script for JoyScroller Chrome Extension

document.addEventListener('DOMContentLoaded', async () => {
  // Load stats
  await loadStats();
  
  // Add event listeners
  document.getElementById('addCurrentPage').addEventListener('click', addCurrentPage);
  document.getElementById('openNewTab').addEventListener('click', openNewTab);
  document.getElementById('openDailyHighlight').addEventListener('click', openDailyHighlight);
});

// Load bookmark statistics
async function loadStats() {
  try {
    const storage = await chrome.storage.local.get();
    const bookmarkKeys = Object.keys(storage).filter(key => key.startsWith('bookmark_'));
    const bookmarks = bookmarkKeys.map(key => storage[key]);
    
    const total = bookmarks.length;
    const unread = bookmarks.filter(bookmark => !bookmark.isRead).length;
    
    document.getElementById('totalBookmarks').textContent = total;
    document.getElementById('unreadBookmarks').textContent = unread;
  } catch (error) {
    console.error('Error loading stats:', error);
    document.getElementById('totalBookmarks').textContent = '0';
    document.getElementById('unreadBookmarks').textContent = '0';
  }
}

// Add current page to bookmarks
async function addCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Get page info from content script
    const pageInfo = await chrome.tabs.sendMessage(tab.id, { action: "getPageInfo" });
    
    // Create bookmark
    const bookmark = await chrome.bookmarks.create({
      title: pageInfo.title,
      url: pageInfo.url,
      parentId: "1" // Bookmarks bar
    });
    
    // Store metadata
    await chrome.storage.local.set({
      [`bookmark_${bookmark.id}`]: {
        id: bookmark.id,
        title: pageInfo.title,
        url: pageInfo.url,
        description: pageInfo.description,
        domain: pageInfo.domain,
        favicon: pageInfo.favicon,
        addedDate: new Date().toLocaleDateString(),
        category: "Read Later",
        isRead: false
      }
    });
    
    // Update button text temporarily
    const button = document.getElementById('addCurrentPage');
    const originalText = button.innerHTML;
    button.innerHTML = '<span>✅</span> Added!';
    button.disabled = true;
    
    setTimeout(() => {
      button.innerHTML = originalText;
      button.disabled = false;
    }, 2000);
    
    // Refresh stats
    await loadStats();
    
  } catch (error) {
    console.error('Error adding bookmark:', error);
    
    const button = document.getElementById('addCurrentPage');
    const originalText = button.innerHTML;
    button.innerHTML = '<span>❌</span> Error';
    
    setTimeout(() => {
      button.innerHTML = originalText;
    }, 2000);
  }
}

// Open new tab with JoyScroller
function openNewTab() {
  chrome.runtime.sendMessage({ action: 'openJoyScrollerTab' });
  window.close();
}

// Open daily highlight in new tab
async function openDailyHighlight() {
  try {
    const storage = await chrome.storage.local.get(['dailyHighlight']);
    
    if (storage.dailyHighlight && storage.dailyHighlight.url) {
      // Open the daily highlight bookmark in a new tab
      chrome.tabs.create({ url: storage.dailyHighlight.url });
      window.close();
    } else {
      // No daily highlight exists, shuffle to get one first
      const allStorage = await chrome.storage.local.get();
      const bookmarkKeys = Object.keys(allStorage).filter(key => key.startsWith('bookmark_'));
      const unreadBookmarks = bookmarkKeys
        .map(key => allStorage[key])
        .filter(bookmark => !bookmark.isRead);
      
      if (unreadBookmarks.length > 0) {
        const randomBookmark = unreadBookmarks[Math.floor(Math.random() * unreadBookmarks.length)];
        
        // Store as daily highlight
        await chrome.storage.local.set({
          'dailyHighlight': randomBookmark
        });
        
        // Open it in new tab
        chrome.tabs.create({ url: randomBookmark.url });
        window.close();
      } else {
        // Show message if no unread bookmarks
        const button = document.getElementById('openDailyHighlight');
        const originalText = button.innerHTML;
        button.innerHTML = '<span>📖</span> No unread bookmarks';
        
        setTimeout(() => {
          button.innerHTML = originalText;
        }, 2000);
      }
    }
  } catch (error) {
    console.error('Error opening daily highlight:', error);
  }
}