/**
 * Mindful Timer Content Script
 * Self-contained timer widget that runs on article pages
 */

class MindfulTimer {
  constructor() {
    this.timeLeft = 25 * 60; // 25 minutes in seconds
    this.isActive = false;
    this.isPaused = false;
    this.interval = null;
    this.overlay = null;
    this.storageKey = 'joyscroller-timer-state';
    
    this.init();
  }

  async init() {
    try {
      // Load saved state
      await this.loadState();
      
      // Create and show timer
      this.createOverlay();
      this.updateDisplay();
      
      // Set up message listener for commands from extension
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
          if (message.action === 'hideTimer') {
            this.hide();
            sendResponse({ success: true });
          }
          return false;
        });
      }
      
      // Auto-hide timer if page navigates away
      window.addEventListener('beforeunload', () => {
        this.hide();
      });
      
      console.log('[JoyScroller] Mindful timer initialized');
    } catch (error) {
      console.error('[JoyScroller] Error initializing timer:', error);
    }
  }

  async loadState() {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      try {
        const result = await chrome.storage.local.get([this.storageKey]);
        const state = result[this.storageKey];
        
        if (state) {
          this.timeLeft = state.timeLeft || 25 * 60;
          this.isActive = state.isActive || false;
          this.isPaused = state.isPaused || false;
          
          // Resume timer if it was active
          if (this.isActive && !this.isPaused) {
            this.startInterval();
          }
        }
      } catch (error) {
        console.warn('[JoyScroller] Could not load timer state:', error);
      }
    }
  }

  async saveState() {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      try {
        await chrome.storage.local.set({
          [this.storageKey]: {
            timeLeft: this.timeLeft,
            isActive: this.isActive,
            isPaused: this.isPaused,
            lastUpdate: Date.now()
          }
        });
      } catch (error) {
        console.warn('[JoyScroller] Could not save timer state:', error);
      }
    }
  }

  createOverlay() {
    // Check if timer already exists
    if (document.getElementById('joyscroller-timer')) {
      return;
    }

    // Detect dark mode
    const isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

    this.overlay = document.createElement('div');
    this.overlay.id = 'joyscroller-timer';
    this.overlay.className = `joyscroller-timer-overlay${isDark ? ' dark' : ''}`;
    
    this.overlay.innerHTML = `
      <div class="joyscroller-timer-header">
        <svg class="joyscroller-timer-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"></circle>
          <polyline points="12,6 12,12 16,14"></polyline>
        </svg>
        <h3 class="joyscroller-timer-title">Mindful Session</h3>
        <button class="joyscroller-timer-close" aria-label="Close timer">×</button>
      </div>

      <div class="joyscroller-timer-display">
        <div class="joyscroller-timer-time">25:00</div>
        <div class="joyscroller-timer-progress">
          <div class="joyscroller-timer-progress-bar" style="width: 0%"></div>
        </div>
      </div>

      <div class="joyscroller-timer-controls">
        <button class="joyscroller-timer-btn primary" data-action="start">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <polygon points="5,3 19,12 5,21"></polygon>
          </svg>
          Start
        </button>
        <button class="joyscroller-timer-btn" data-action="restart">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"></path>
            <path d="M21 3v5h-5"></path>
            <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"></path>
            <path d="M3 21v-5h5"></path>
          </svg>
        </button>
        <button class="joyscroller-timer-btn" data-action="stop">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <rect x="6" y="6" width="12" height="12"></rect>
          </svg>
        </button>
      </div>

      <p class="joyscroller-timer-message">
        Stay focused and browse mindfully
      </p>
    `;

    // Add event listeners
    this.overlay.querySelector('.joyscroller-timer-close').addEventListener('click', () => {
      this.hide();
    });

    this.overlay.addEventListener('click', (e) => {
      const action = e.target.closest('[data-action]')?.dataset.action;
      if (action) {
        this.handleAction(action);
      }
    });

    // Add keyboard support
    this.overlay.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.hide();
      } else if (e.key === ' ' || e.key === 'Enter') {
        const focused = document.activeElement;
        if (focused && focused.dataset.action) {
          this.handleAction(focused.dataset.action);
        }
      }
    });

    document.body.appendChild(this.overlay);
  }

  handleAction(action) {
    switch (action) {
      case 'start':
        if (!this.isActive) {
          this.start();
        } else {
          this.togglePause();
        }
        break;
      case 'restart':
        this.restart();
        break;
      case 'stop':
        this.stop();
        break;
    }
  }

  start() {
    this.isActive = true;
    this.isPaused = false;
    this.startInterval();
    this.updateControls();
    this.saveState();
  }

  togglePause() {
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      this.stopInterval();
    } else {
      this.startInterval();
    }
    this.updateControls();
    this.saveState();
  }

  restart() {
    this.stop();
    this.timeLeft = 25 * 60;
    this.start();
  }

  stop() {
    this.isActive = false;
    this.isPaused = false;
    this.timeLeft = 25 * 60;
    this.stopInterval();
    this.updateDisplay();
    this.updateControls();
    this.saveState();
  }

  hide() {
    if (this.overlay) {
      this.overlay.remove();
      this.overlay = null;
    }
    this.stopInterval();
    
    // Clear storage state
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.remove([this.storageKey]).catch(() => {});
    }
  }

  startInterval() {
    this.stopInterval();
    this.interval = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
        this.updateDisplay();
        this.saveState();
      } else {
        this.onTimerComplete();
      }
    }, 1000);
  }

  stopInterval() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  onTimerComplete() {
    this.isActive = false;
    this.isPaused = false;
    this.stopInterval();
    this.updateControls();
    this.saveState();

    // Show completion notification
    this.showNotification();
  }

  showNotification() {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('JoyScroller', {
        body: 'Reading session completed! Time for a break.',
        icon: '/icons/icon48.png',
        silent: false
      });
    }
  }

  updateDisplay() {
    if (!this.overlay) return;

    const timeDisplay = this.overlay.querySelector('.joyscroller-timer-time');
    const progressBar = this.overlay.querySelector('.joyscroller-timer-progress-bar');

    if (timeDisplay) {
      timeDisplay.textContent = this.formatTime(this.timeLeft);
    }

    if (progressBar) {
      const progress = ((25 * 60 - this.timeLeft) / (25 * 60)) * 100;
      progressBar.style.width = `${progress}%`;
    }
  }

  updateControls() {
    if (!this.overlay) return;

    const startBtn = this.overlay.querySelector('[data-action="start"]');
    
    if (startBtn) {
      if (!this.isActive) {
        startBtn.innerHTML = `
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <polygon points="5,3 19,12 5,21"></polygon>
          </svg>
          Start
        `;
        startBtn.className = 'joyscroller-timer-btn primary';
      } else if (this.isPaused) {
        startBtn.innerHTML = `
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <polygon points="5,3 19,12 5,21"></polygon>
          </svg>
        `;
        startBtn.className = 'joyscroller-timer-btn';
      } else {
        startBtn.innerHTML = `
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <rect x="6" y="4" width="4" height="16"></rect>
            <rect x="14" y="4" width="4" height="16"></rect>
          </svg>
        `;
        startBtn.className = 'joyscroller-timer-btn';
      }
    }
  }

  formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
}

// Initialize timer when script loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new MindfulTimer();
  });
} else {
  new MindfulTimer();
}