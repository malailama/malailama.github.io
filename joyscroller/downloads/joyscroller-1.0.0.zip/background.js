// Background script for JoyScroller Chrome Extension

// Create context menu for adding bookmarks
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "addToJoyScroller",
    title: "Add to JoyScroller",
    contexts: ["link", "page"]
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "addToJoyScroller") {
    const url = info.linkUrl || info.pageUrl || tab.url;
    const title = info.selectionText || tab.title || url;
    
    try {
      // Add bookmark to Chrome's bookmark system
      const bookmark = await chrome.bookmarks.create({
        title: title,
        url: url,
        parentId: "1" // Bookmarks bar folder
      });
      
      // Store additional metadata in chrome.storage
      await chrome.storage.local.set({
        [`bookmark_${bookmark.id}`]: {
          id: bookmark.id,
          title: title,
          url: url,
          addedDate: new Date().toLocaleDateString(),
          category: "Read Later",
          isRead: false,
          domain: new URL(url).hostname.replace('www.', '')
        }
      });
      
      // Add to JoyScroller reading list using sync storage
      const [localStorage, syncStorage] = await Promise.all([
        chrome.storage.local.get(['readingLists']),
        chrome.storage.sync.get(['readingLists'])
      ]);
      
      let readingLists = localStorage.readingLists || [];
      let syncReadingLists = syncStorage.readingLists || {};
      
      // Ensure "Saved to JoyScroller" list exists in local storage
      let joyScrollerList = readingLists.find(list => list.id === 'saved-to-joyscroller');
      if (!joyScrollerList) {
        joyScrollerList = {
          id: 'saved-to-joyscroller',
          name: 'Saved to JoyScroller',
          count: 0,
          bookmarks: []
        };
        readingLists.unshift(joyScrollerList);
        await chrome.storage.local.set({ readingLists });
      }
      
      // Ensure "Saved to JoyScroller" list exists in sync storage
      if (!syncReadingLists['saved-to-joyscroller']) {
        syncReadingLists['saved-to-joyscroller'] = {
          id: 'saved-to-joyscroller',
          name: 'Saved to JoyScroller',
          createdAt: new Date().toISOString(),
          bookmarkIds: []
        };
      }
      
      // Add bookmark to sync storage reading list
      if (!syncReadingLists['saved-to-joyscroller'].bookmarkIds.includes(bookmark.id)) {
        syncReadingLists['saved-to-joyscroller'].bookmarkIds.push(bookmark.id);
        await chrome.storage.sync.set({ readingLists: syncReadingLists });
        
        // Update local storage count to match
        joyScrollerList.bookmarks.push(bookmark.id);
        joyScrollerList.count = joyScrollerList.bookmarks.length;
        await chrome.storage.local.set({ readingLists });
      }
      
      // Show notification
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: 'JoyScroller',
        message: `Added "${title}" to JoyScroller`
      });
    } catch (error) {
      console.error('Error adding to JoyScroller:', error);
      // Show error notification
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: 'JoyScroller Error',
        message: 'Failed to add bookmark to JoyScroller'
      });
    }
  }
});

// Sync bookmarks on startup
chrome.runtime.onStartup.addListener(() => {
  syncBookmarks();
});

// Function to sync Chrome bookmarks with JoyScroller data
async function syncBookmarks() {
  try {
    const bookmarkTree = await chrome.bookmarks.getTree();
    const storage = await chrome.storage.local.get();
    
    // Process bookmarks and ensure they have JoyScroller metadata
    function processBookmarks(nodes) {
      nodes.forEach(node => {
        if (node.url && !storage[`bookmark_${node.id}`]) {
          // Add missing metadata for existing bookmarks
          chrome.storage.local.set({
            [`bookmark_${node.id}`]: {
              id: node.id,
              title: node.title,
              url: node.url,
              addedDate: new Date(node.dateAdded).toLocaleDateString(),
              category: "Read Later",
              isRead: false,
              domain: new URL(node.url).hostname
            }
          });
        }
        
        if (node.children) {
          processBookmarks(node.children);
        }
      });
    }
    
    processBookmarks(bookmarkTree);
  } catch (error) {
    console.error('Error syncing bookmarks:', error);
  }
}

// Handle bookmark changes
chrome.bookmarks.onCreated.addListener(async (id, bookmark) => {
  if (bookmark.url) {
    await chrome.storage.local.set({
      [`bookmark_${id}`]: {
        id: id,
        title: bookmark.title,
        url: bookmark.url,
        addedDate: new Date().toLocaleDateString(),
        category: "Read Later", 
        isRead: false,
        domain: new URL(bookmark.url).hostname.replace('www.', '')
      }
    });
  }
});

chrome.bookmarks.onRemoved.addListener((id) => {
  chrome.storage.local.remove(`bookmark_${id}`);
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[JoyScroller Background] Received message:', message);
  
  if (message.action === 'updateNewTabBehavior') {
    // Store the setting
    chrome.storage.local.set({ newTabOverride: message.enabled });
    sendResponse({ success: true });
  } else if (message.action === 'openJoyScrollerTab') {
    // Always open JoyScroller in a new tab, regardless of new tab override settings
    chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
    sendResponse({ success: true });
  } else if (message.action === 'ensureContextMenu') {
    // Ensure context menu exists (useful after extension reload)
    try {
      chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
          id: "addToJoyScroller",
          title: "Add to JoyScroller",
          contexts: ["link", "page"]
        }, () => {
          if (chrome.runtime.lastError) {
            console.error('[JoyScroller Background] Error recreating context menu:', chrome.runtime.lastError);
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
          } else {
            console.log('[JoyScroller Background] Context menu recreated successfully');
            sendResponse({ success: true });
          }
        });
      });
    } catch (error) {
      console.error('[JoyScroller Background] Error ensuring context menu:', error);
      sendResponse({ success: false, error: error.message });
    }
    return true; // Will respond asynchronously
  } else if (message.action === 'injectTimer') {
    console.log('[JoyScroller Background] Injecting timer into tab:', message.tabId);
    // Add a small delay to ensure tab is ready
    setTimeout(() => {
      injectTimerIntoTab(message.tabId)
        .then(() => {
          console.log('[JoyScroller Background] Timer injection successful');
          sendResponse({ success: true });
        })
        .catch(error => {
          console.error('[JoyScroller Background] Timer injection failed:', error);
          sendResponse({ success: false, error: error.message });
        });
    }, 1000); // 1 second delay to ensure tab is ready
    return true; // Will respond asynchronously
  } else if (message.action === 'syncBookmarks') {
    syncBookmarks().then(async () => {
      try {
        await syncChromeReadingList();
        sendResponse({ success: true });
      } catch (error) {
        console.error('[JoyScroller] Error syncing reading list:', error);
        sendResponse({ success: true }); // Still success for bookmarks
      }
    }).catch((error) => {
      sendResponse({ success: false, error: error.message });
    });
    return true; // Will respond asynchronously
  } else if (message.action === 'getCurrentTabId') {
    sendResponse({ tabId: sender.tab?.id });
  }
});

// Inject mindful timer into a specific tab
async function injectTimerIntoTab(tabId) {
  try {
    console.log('[JoyScroller Background] Starting timer injection for tab:', tabId);
    
    // Check if tab is still valid
    const tab = await chrome.tabs.get(tabId);
    if (!tab || !tab.url) {
      throw new Error('Tab no longer exists or has no URL');
    }
    
    console.log('[JoyScroller Background] Tab URL:', tab.url);
    
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('edge://')) {
      throw new Error('Cannot inject into system page');
    }

    // Wait for page to load
    await waitForTabLoad(tabId);
    console.log('[JoyScroller Background] Tab loaded, injecting CSS and JS');

    // Check if tab still exists before injection
    const tabBeforeInject = await chrome.tabs.get(tabId);
    console.log('[JoyScroller Background] Tab before injection:', tabBeforeInject.url, 'status:', tabBeforeInject.status);

    // Inject CSS first
    try {
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ['content/mindful-timer.css']
      });
      console.log('[JoyScroller Background] CSS injected successfully');
    } catch (cssError) {
      console.error('[JoyScroller Background] CSS injection error:', cssError);
      throw new Error(`CSS injection failed: ${cssError.message}`);
    }

    // Then inject JavaScript
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content/mindful-timer.js']
      });
      console.log('[JoyScroller Background] JavaScript injected successfully');
    } catch (jsError) {
      console.error('[JoyScroller Background] JS injection error:', jsError);
      throw new Error(`JS injection failed: ${jsError.message}`);
    }

    console.log('[JoyScroller Background] Timer injected into tab:', tabId);
  } catch (error) {
    console.error('[JoyScroller Background] Error injecting timer:', error);
    throw error;
  }
}

// Wait for tab to finish loading with retry logic
async function waitForTabLoad(tabId) {
  const maxRetries = 10;
  const retryDelay = 500;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === 'complete') {
        return;
      }
    } catch (error) {
      throw new Error('Tab no longer exists');
    }
    
    await new Promise(resolve => setTimeout(resolve, retryDelay));
  }
  
  // Proceed anyway after max retries
  console.warn('[JoyScroller] Tab load timeout, injecting anyway');
}

// Sync Chrome reading list with JoyScroller
async function syncChromeReadingList() {
  try {
    // Check if Chrome Reading List API is available
    if (!chrome.readingList) {
      console.warn('Chrome Reading List API not available');
      return;
    }

    const entries = await chrome.readingList.query({});
    const storage = await chrome.storage.local.get();
    let readingLists = storage.readingLists || [];

    // Remove old Chrome reading list entry
    readingLists = readingLists.filter(list => !list.isChrome);

    // Clean up any existing reading list bookmark metadata to avoid duplicates
    const existingReadingListKeys = Object.keys(storage).filter(key =>
      key.startsWith('bookmark_chrome_reading_')
    );
    if (existingReadingListKeys.length > 0) {
      await chrome.storage.local.remove(existingReadingListKeys);
    }

    if (entries.length > 0) {
      // Create bookmark metadata for reading list entries
      const bookmarkIds = [];

      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        // Use a consistent ID based on the entry URL for stability
        const urlHash = btoa(entry.url).replace(/[^a-zA-Z0-9]/g, '').slice(0, 20);
        const entryId = `chrome_reading_${urlHash}`;
        bookmarkIds.push(entryId);

        // Store metadata for this reading list entry
        await chrome.storage.local.set({
          [`bookmark_${entryId}`]: {
            id: entryId,
            title: entry.title || entry.url,
            url: entry.url,
            description: 'From Chrome Reading List',
            domain: new URL(entry.url).hostname.replace('www.', ''),
            category: 'Read Later',
            favicon: `chrome://favicon/size/32@1x/${entry.url}`,
            isRead: false,
            addedDate: new Date(entry.creationTime || Date.now()).toLocaleDateString(),
            isFromReadingList: true
          }
        });
      }

      // Add Chrome reading list
      const chromeReadingList = {
        id: 'chrome-reading-list',
        name: 'Chrome Reading List',
        count: entries.length,
        bookmarks: bookmarkIds,
        isChrome: true
      };

      readingLists.unshift(chromeReadingList);
    }

    await chrome.storage.local.set({ readingLists });
    console.log('Chrome Reading List synced successfully');
  } catch (error) {
    console.error('Error syncing Chrome reading list:', error);
    throw error;
  }
}

// Permission notifications
chrome.permissions.onAdded.addListener((permissions) => {
  console.log('JoyScroller permissions added:', permissions);
});

chrome.permissions.onRemoved.addListener((permissions) => {
  console.log('JoyScroller permissions removed:', permissions);
});